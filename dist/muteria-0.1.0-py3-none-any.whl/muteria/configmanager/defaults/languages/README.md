Put Programming language defaults configs here.

Each has the name of the programming language