""" Put in here the extra configuration that can be passed for a 
specific part of the tool. 
Example: linking flags for compiling llvm module into executable

The format is <Component using>__<Module of Functionality>__<Parameter name>
"""

CODE_BUILD_FACTORY__LLVM__LINKING_FLAGS = None