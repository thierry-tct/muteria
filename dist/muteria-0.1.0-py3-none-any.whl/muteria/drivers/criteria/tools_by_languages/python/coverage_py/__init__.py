
from muteria.drivers.criteria.tools_by_languages.python.coverage_py.coverage \
                                                import CriteriaToolCoveragePy 

#from .gcov import CriteriaToolGCov

StaticCriteriaTool = CriteriaToolCoveragePy
