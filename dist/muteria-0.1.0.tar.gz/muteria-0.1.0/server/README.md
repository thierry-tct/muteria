# Muteria Server
 TODO: Add `flask` requirement
## Using flask and bootstrap template to run *muteria* with GUI

##Note:
1. Use [codemirror](https://codemirror.net/) for online code editing.
2. use [pygment](http://pygments.org/) for code display from server (jinga2 template)
3. Use [layoutit](https://www.layoutit.com/build) for building bootstrap templates.