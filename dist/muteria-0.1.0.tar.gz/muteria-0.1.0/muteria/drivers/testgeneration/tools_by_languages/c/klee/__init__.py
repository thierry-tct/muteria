from muteria.drivers.testgeneration.tools_by_languages.c.klee.klee \
                                                    import TestcasesToolKlee 
StaticTestcaseTool = TestcasesToolKlee
DynamicTestcaseTool = None