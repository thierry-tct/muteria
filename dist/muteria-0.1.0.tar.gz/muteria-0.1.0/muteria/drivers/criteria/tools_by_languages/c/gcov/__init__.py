
from muteria.drivers.criteria.tools_by_languages.c.gcov.gcov \
                                                        import CriteriaToolGCov 

#from .gcov import CriteriaToolGCov

StaticCriteriaTool = CriteriaToolGCov
