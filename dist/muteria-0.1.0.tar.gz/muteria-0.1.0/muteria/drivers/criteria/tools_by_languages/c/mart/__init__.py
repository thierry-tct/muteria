
from muteria.drivers.criteria.tools_by_languages.c.mart.mart \
                                                        import CriteriaToolMart 


StaticCriteriaTool = CriteriaToolMart
